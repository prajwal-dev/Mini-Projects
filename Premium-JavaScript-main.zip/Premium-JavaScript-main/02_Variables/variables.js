// console hamara print karta hai output ko screen pe
// console.log("hello")

// ye hmara single line comment hai aljdsflk as;ld lkds jlksajd flkajdsflkjasdlkfj lakdsj f;lkajdslfkj sadlkjflksadj flkjdsa lfk jlsakdjflk jdsa

/*
ye hamara
multiple line
comment hai
*/

// let age;
// age = 24
// console.log(age)

// let name = "Manas Kumar Lal"
// name = "ram"
// console.log(name)

// let alpha = "lakjdslkfj sadlfkj s;dlf jaf";
// console.log(alpha)

// let a;
// let b;
// let c;

// a = 10;
// b = 20;
// c = 30;

// let a = 10;
// let b = 20;
// let c = 30;

// let a,b,c;
// a = 10;
// b=20;
// c=30;

// let a = 10;
// let b;
// let c;



// console.log(a,b,c)
// console.log(a)
// console.log(b)
// console.log(c)

// let a = 1;
// let a = 10;


// {
//     let age = 1;
//     let name = "manas"
//     console.log(age);
//     console.log(name)
// }

// console.log(age);
// console.log("hello")

// const pi = 3.14;
// const a = 10;
// // a = 15;

// // pi = 2;
// console.log(pi)

// let alpha;
// console.log(alpha)

// let name = "halwa"
// let Name = "gazar ka halwa"
// console.log(name)
// console.log(Name)

// let name;
// let name1;
// let name_;
// let name$;

// let $name;

// let full_name;

// let price1 = 499;
// let price2 = 299;

// let totalPrice = price1 + price2;
// console.log(totalPrice)

// let name = prompt("Enter name");
// let lastName = prompt("Enter last name");
// let fullName = name + " " + lastName;
// console.log(fullName)

/*
let a = 1
a = "alpha"

a = true
console.log(typeof a)
console.log(typeof(a))

let a1 = "2" + 2;
let a2 = "2" - 2
console.log(a1, typeof a1)
console.log(a2, typeof a2)

alpha = 22;
console.log(alpha)
*/

// console.log(beta)

// let name;
// let name1 = null;
// console.log(name, typeof name)
// console.log(name1, typeof name1)

// let number = BigInt(23432432);


// console.log(number, typeof number)

// let isLoggedIn = false;
// console.log(isLoggedIn, typeof isLoggedIn)

// let str = "23";
// let num = Number(str);
// console.log(num, typeof num)

let num = Number(prompt("Enter a number"));
console.log(num, typeof num);