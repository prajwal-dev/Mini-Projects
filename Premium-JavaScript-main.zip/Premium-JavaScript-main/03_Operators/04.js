let x = 5;
console.log(x)
x += 3; // x = x + 3 → 8
console.log(x)
x -= 2; // x = x - 2 → 6
console.log(x)
x *= 4; // x = x * 4 → 24
console.log(x)
x /= 6; // x = x / 6 → 4
console.log(x)
x %= 3; // x = x % 3 -> 1
console.log(x)
