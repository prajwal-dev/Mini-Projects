let a = 5, b = 3, c = 2;

let result = a++ + --b * c-- - ++a + b-- / --c;

console.log("a:", a);
console.log("b:", b);
console.log("c:", c);
console.log("result:", result);