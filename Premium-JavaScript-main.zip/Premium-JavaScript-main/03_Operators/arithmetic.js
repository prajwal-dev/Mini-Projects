// console.log("5 + 2 = ", 5 + 2)
// console.log("5 - 2 = ", 5 - 2)
// console.log("5 * 2 = ", 5 * 2)
// console.log("10 / 3 = ", 10 / 3)
// console.log("5 % 2 = ", 5 % 2)
// console.log("5 ** 2 = ", 5 ** 2)

// challenge 1
let pricePerItem = 150;
let quantity = 3;
let totalPrice = pricePerItem * quantity;
let discount = totalPrice * 0.1;
let discountPrice = totalPrice - discount;

console.log("price per item = ", pricePerItem);
console.log("quantity = ", quantity);
console.log("totalPrice = ", totalPrice);
console.log("discount = ", discount);
console.log("discountPrice = ", discountPrice);