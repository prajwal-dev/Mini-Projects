let a = 5;
console.log(a);
a = a + 5;
console.log(a);
a += 5; // a = a + 5;
console.log(a);

a -= 3;
console.log(a)

a *= 2; // a = a * 2;
console.log(a);

a /= 3; // a = a / 3;
console.log(a);

a %= 3; // a= a % 2;
console.log(a);

a **= 3; // a = a ** 3;
console.log(a);