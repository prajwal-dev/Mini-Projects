// console.log(5&3);
// console.log(4&7);

// console.log(8 | 11);
// console.log(26 | 15);

// console.log(~3)
// console.log(~0)
// console.log(~(-5))

