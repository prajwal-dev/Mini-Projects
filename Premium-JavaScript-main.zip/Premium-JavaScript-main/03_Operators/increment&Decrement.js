// let a = 5;
// console.log(a)
// console.log(a++)
// console.log(a); //6
// console.log(--a); //5
// console.log(a--);
// console.log(a)

let a = 10;
let result = a++ + ++a - 10;
console.log(result)