// let num1 = Number(prompt("Enter first number: "));
// let num2 = Number(prompt("Enter 2nd number: "));

// console.log("num1 + num2 = ", num1 + num2);
// console.log("num1 - num2 = ", num1 - num2);
// console.log("num1 * num2 = ", num1 * num2);
// console.log("num1 / num2 = ", num1 / num2);
// console.log("num1 % num2 = ", num1 % num2);
// console.log("num1 ** num2 = ", num1 ** num2);

// let a = b= c = 15;
// console.log(a)
// console.log(b)
// console.log(c)


// let num1 = Number(prompt("Enter number: "));

// let result = (num1 % 2 === 0) ? "Even number": "odd number";
// console.log(result);

// let num = 10;
// let result = (num>=10 && num<=20)
// console.log(result);

// let a = 1, b=13, c=2;
// let result = a>b ? (a>c ? a : c) :(b>c ? b : c)
// console.log(result); 

// let username = "mkl";
// let password = "12345";

// let databaseUser = "mkl";
// let databasePassword = "12345"

// let result = (username && password && username === databaseUser && password === databasePassword)
//     ?
//     "login successfull"
//     :
//     "invalid username or password"

// console.log(result)

console.log(2 < "6")
