// let age = 8;
// let result = age >= 18 ? "Eligible for booking" : "Not eligible for booking";
// console.log(result);

// let username = "asgsdg";
// let password = "asdgsdgs";
// const result = (username && password) ? ("login successfull") : ("username & password are required!")
// console.log(result);

let a = 1, b = 2, c = 0;

let result = a>b ? (a>c ? a : c) : (b>c ? b : c);
console.log(result);