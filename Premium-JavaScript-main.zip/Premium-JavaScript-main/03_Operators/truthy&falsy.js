// let username = "asdg";
// let password = "asgdsdgsdg";

// let result = (username && password) ? ("sucessfull login") : ("invalid username or password")
// console.log(result)

// console.log("" || undefined || false || null || 0n);
// console.log("rohan" && 23 && 35 && "Mnas Kumar")
let result = "alpha" ?? "mkl";
console.log(result)