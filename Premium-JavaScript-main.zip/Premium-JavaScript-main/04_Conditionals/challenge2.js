let subscriptionType = "asdfdsaf"

if(subscriptionType === "premium"){
    console.log("you have access of all content")
}else if(subscriptionType === 'standard'){
    console.log("you have access to limited content")
}else{
    console.log("not a valid subscription");
}