let age = 6;

if (age >= 18) {
    console.log("you can drive")
} else {
    console.log("you can't drive")
}

if (age >= 18) console.log("you can drive");
else console.log("you can't drive")

let result = age>=18 ? "you can drive" : "you can't drive"
console.log(result)