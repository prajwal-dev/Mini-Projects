let clr = "orange"

switch (clr) {
    case "red":
        console.log("stop!");
        break;
    case "yellow":
        console.log("warning");
        break;
    case "green":
        console.log("go");
        break;
    default:
        console.log("invalid color")
}