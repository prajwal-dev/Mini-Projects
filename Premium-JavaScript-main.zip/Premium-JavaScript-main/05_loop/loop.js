// for(let i=1; i<=10 ; i++){
//     console.log(i);
// }

// let i=1;
// while(i<=10){
//     console.log(i);
//     i++;
// }

// let i = 100;
// do {
//     console.log(i)
//     i++;
// } while (i <= 5)

// let str = "Manas Kumar Lal"
// for(let ch of str){
//     console.log(ch)
// }

// for(let i=0 ; i<str.length;i++){
//     console.log(str[i])
// }

// for(let ch in str){
//     console.log(ch)
// }

// challenge1

// for (let i=0 ;i<=100; i++){
//     if(i%2===0){
//         console.log(i)
//     }
// }

// let str = "alphabhtuo "
// let vowelCount = 0;
// let consonentCount = 0
// for (let ch of str) {
//     if (ch === 'a' || ch === 'e' || ch === 'i' || ch === 'o' || ch === 'u' || ch === 'A' || ch === 'E' || ch === 'I' || ch === 'O' || ch === 'U') {
//         vowelCount++;
//     } else if (ch === " ") {
//         console.log("space not counted")
//     } else {
//         consonentCount++;
//     }
// }

// console.log("Vowel Count = ", vowelCount)
// console.log("Consonent Count = ", consonentCount)