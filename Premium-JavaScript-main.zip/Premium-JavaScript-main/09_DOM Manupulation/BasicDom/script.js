/*

5 phases of dom manupulation:

1. DOM ✅
2. Selection of HTML Elements ✅
3. How to change or manupulate HTML ✅
4. CSS Ko kaise change kar skte hai ✅
5. Event Listeners (event ko kaise suna jaaaye)

*/

// let h1 = document.querySelector('h1');
// h1.innerHTML = "meri girlfriend hai hi nai"

// let p = document.querySelector('p');
// p.innerHTML = "jo karna hai mere samne karo mai bhi dekhna chahta hun"


// let a = document.querySelector('h1');
// a.style.backgroundColor = 'rgba(0,255,0)'
// a.style.color = 'black'

// let b = document.querySelector('p');
// b.style.backgroundColor = 'rgba(0,255,0)'
// b.style.color = 'black'


// let h1 = document.querySelector('h1');
// h1.addEventListener('click', ()=>{
//     h1.style.backgroundColor = 'green'
//     h1.style.color = 'black'
//     h1.innerHTML = 'meri girlfriend bhaut hi jyada wo hai'
// })


// let box = document.querySelector('div');

// let button = document.querySelector('button')
// let offButton = document.querySelector('.offButton')
// button.addEventListener('click', ()=>{
//     box.style.scale = "1"
// })

// offButton.addEventListener('click',()=>{
//     box.style.scale = "0.5"
// })