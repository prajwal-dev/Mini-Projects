// let date = new Date('2023-05-16T02:00:00'); // ISO Standard
// console.log(date.toLocaleString()) 


// let date2 = new Date(2025, 4, 20, 5, 4, 3)
// console.log(date2.toLocaleString()) 

// let date3 = new Date(1747836516033);
// console.log(date3.toLocaleString())


// let date4 = new Date(date3);
// console.log(date4)


// let date = new Date();
// console.log(date);
// console.log(date.getFullYear());
// console.log(date.getMonth()); // zero indexed
// console.log(date.getDate());
// console.log(date.getDay());
// console.log(date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());


// console.log(date.getTimezoneOffset()/60) // minutes (UTC - local)


// date.setFullYear('2023')
// date.setMonth(0)
// date.setDate(15)

// console.log(date)


// let ts = new Date().getTime();
// console.log(ts)

// let timeStamps = Date.now();
// console.log(timeStamps)


// let date = new Date();
// console.log(date.toISOString());
// console.log()
// console.log(date.toString());
// console.log(date.toDateString());
// console.log(date.toTimeString());
// console.log()
// console.log(date.toLocaleString())
// console.log(date.toLocaleDateString())
// console.log(date.toLocaleTimeString())

// console.log()
// console.log(`${date.getDate()} day ${date.getMonth() + 1} month ${date.getFullYear()} year`)

// 05 day 10 month 2025 year
