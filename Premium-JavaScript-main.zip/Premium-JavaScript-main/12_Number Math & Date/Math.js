// console.log(Math.floor(1))
// console.log(Math.floor(1.5))
// console.log(Math.floor(1.9))
// console.log(Math.floor(2.6))
// console.log(Math.floor(-2.6))

// console.log(Math.ceil(1))
// console.log(Math.ceil(1.5))
// console.log(Math.ceil(1.9))
// console.log(Math.ceil(2.6))
// console.log(Math.ceil(-2.6))

// console.log(Math.abs(-3))
// console.log(Math.abs(3))
// console.log(Math.abs(0))
// console.log(Math.abs(-0))

// console.log(Math.sqrt(9))
// console.log(Math.pow(2,6))

console.log(Math.min(2,3,43,5,43,53,46,436))
console.log(Math.max(2,3,43,5,43,53,46,436))