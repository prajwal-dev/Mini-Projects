// Number

// let num = 1234234234n;
// let num1 = 1234.23423;
// console.log(typeof num)
// console.log(typeof num1)

// let num = new Number('13241234')
// console.log(num)

// let a = 0/0;
// console.log(a)

// console.log(Number.MAX_VALUE)
// console.log(Number.MIN_VALUE)
// console.log(Number.POSITIVE_INFINITY)
// console.log(Number.NEGATIVE_INFINITY)
// console.log(Number.NaN)
// console.log(Number.isNaN(a))
// console.log(Number.EPSILON)

// let num = '123.834px';

// console.log(Number.parseInt(num))
// console.log(parseFloat(num))

// let num = 1/0;

// console.log(Number.isFinite(num))
// console.log(isFinite(num));


let num = 123.12545678;
// console.log(num.toFixed(4));

// console.log(num.toExponential(3))
// console.log(num.toPrecision(2))

// console.log(num.toString())
// let num2 = new String('12345');

// console.log(num2)
// console.log(num2.valueOf())
