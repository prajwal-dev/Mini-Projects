// setTimeout(() => {
//     console.log("kapde dhul gye")
// }, 7000);

// setTimeout(() => {
//     console.log("chawal ban gya")
// }, 3000);

// setTimeout(() => {
//     console.log("sabji ban gya")
// }, 6000);



// console.log("Hey guys do you want coffee");

// console.log("muskan servers coffee");

// setTimeout(() => {
//     for(let i=1; i<=400000; i++){
//         console.log('person', i)
//     }
// }, 100);

// console.log("Dance seekhna hai")



// async function fetchData() {
//     let response = await fetch('https://jsonplaceholder.typicode.com/users');
//     console.log(await response.json());
// }

// fetchData();

// console.log("hello")
// console.log("some important task")