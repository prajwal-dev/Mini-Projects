/*
    settimeout
    setinterval
    fetch
    axios
*/

// console.log("1st task")

// setTimeout(() => {
//     console.log("2nd task")
// }, 2000);

// console.log("3rd task")



// console.log("1")

// setTimeout(() => {
//     console.log("2")
// }, 5000);

// console.log("3")
// console.log("4")

// setTimeout(() => {
//     console.log("5")
// }, 3000);

// console.log("6")