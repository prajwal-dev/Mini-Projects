/*

** synchronous and asynchronous kya hota hai?✅

synchronous apka line by line chalta hai
asynchronous apka non-blocking hota hai ar aage ke instruction ko block nahi karta hai,,,, lagta hai ki multiple tasks ek sath chal rhe hai but aaisa hota nai h actually
asynchronous pechanne ka tarika -> time lagega
settimeout
setintermal
XMLHttpRequest
fetch
axios


** javascript by default async nahi hota.
definately, javascript to sync in nature hota hai by default,  sync to bnaya ja skta hai✅

** single threading and multi threading ✅

** callbacks ✅

hamesa ek function hota hai joki as a argument ham kisi function ke andar pass kar rhe hote hai , and jis function ke andar ham pass kar rhe hote hai use ham hod (higher order function) kehte hai

ar iska naam callback isliye hai kyunki need padne me ham call back kar lete h function ko jaise ki ham apni gf ko call back kar lete h missed call dekh kar

** callback hell ✅
nested callbacks

** promises✅

promises callback hell se nikalne ka ek tarika hai jha pe ham kehte h ki koi task future me ya to resolve hoga ya to reject hoga and uske according ham .then and .catch use kar rhe hote h

promise ke sath sath hi fetch aaya tha market me joki actual promise return kar rha hota h and ham actual database ke sath kam kar rhe hote h jha pe data aane me time lagta hai.

** promise chaining ✅

.then ke bad .then ke baad .then and so on

** async await 

async await promises pe hi kam karta hai but bhaut jyada pyara syntax hota hai ✅

** try catch ✅

aaisa code jisme error aane ki sambhawna hoti hai usse ham try ke andar wrap kar dete hai ar catch block ke andar error catch kar lete h ar error show kar dete hai

** IIFE (immediately invoked function expression) ✅

isse hame call karne ki need nahi padti ye khud call ho jata hai
async await ke liye bhaut badhiya h kafi cases me.

** promise to bas bhana asli maksad to api ke sath khel jana hai ✅

** data aane me time lagta hai, to javascript banki kam ko rok ke rakhne ke wjay promise deke bolta hai aage badho chu**ye. ✅

*/

// js complete ho chuka h laghbhag
// chote chote pyare pyare lectures
// 4 hrs, 5hrs, 5hr+ , 3hrs 👇🏻
// string, array, object --> 5hr
// dom --> 5hrs
// functional programming --> 4hrs
// oops --> 4hrs
// async await --> 4hr+
// interview js --> hoisting, tdz, closurs, debouncing, throtlling, memoization, event loop,,............................


// REACT v/s Interview JS